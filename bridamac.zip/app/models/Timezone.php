<?php

class Timezone extends Eloquent 
{
	public $timestamps = false;
	protected $softDelete = false;	
}