<?php

class InvoiceStatus extends Eloquent
{
	public $timestamps = false;
	protected $softDelete = false;	
}
