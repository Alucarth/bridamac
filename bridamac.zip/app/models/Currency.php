<?php

class Currency extends Eloquent
{
	public $timestamps = false;
	protected $softDelete = false;	
}