<?php

class MasterDocument extends Eloquent
{
	public $timestamps = true;
	
}