<?php

class Invitation extends Eloquent
{
	
}