<?php

$fac = $invoice->javascript;

eval($fac);


?>
