<!DOCTYPE html>
<html>

<body>
<p>
    <h1> Bienvenido a EMIZOR </h1>
   
    Gracias por pensar en nosotros como su proveedor de facturación electrónica.<br>
   
    <h3>Para ingresar a su cuenta</h3>
   
    Puede utilizar su cuenta de EMIZOR a través de Internet; ya sea por el portal, desde dispositivos móviles o tabletas.<br>
    {{$direccion}}</a>
    <h3>¿Necesita asistencia?</h3>

    Para comenzar le recomendamos leer nuestra sección de preguntas frecuentes, en caso de tener alguna duda le invitamos a ponerse en contacto con nuestro equipo de soporte donde un asesor le brindará atención personalizada.<br><br>

    Nuestros números telefónicos son  en horarios de 9:00 a 13:00 hrs y de 14:00 a 17:30 hrs<br><br>

    Saludos Coordiales,<br>
    El equipo de EMIZOR<br>
    www.emizor.com<br>
 
</p>
</body>
</html>

